// Elaborado por : Samuel Alzate y Santiago Atehortua

import GreetModel from "./models/GreetModel.js";
import MessageModel from "./models/MessageModel.js";
import CounterModel from "./models/CounterModel.js";
import ToggleModel from "./models/ToggleModel.js";

import GreetView from "./views/GreetView.js";
import MessageView from "./views/MessageView.js";
import CounterView from "./Views/CounterView.js";
import ToggleView from "./views/ToggleView.js";

import GreetController from "./controllers/GreetController.js";
import MessageController from "./controllers/MessageController.js";
import CounterController from "./controllers/CounterController.js";
import ToggleController from "./controllers/ToggleController.js";

document.addEventListener("DOMContentLoaded", () => {
    new GreetController(new GreetModel(), new GreetView());
    new MessageController(new MessageModel(), new MessageView());
    new CounterController(new CounterModel(), new CounterView());
    new ToggleController(new ToggleModel(), new ToggleView());
});
