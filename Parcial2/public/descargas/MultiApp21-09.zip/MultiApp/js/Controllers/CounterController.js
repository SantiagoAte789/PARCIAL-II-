export default class CounterController {
    constructor(model, view) {
        this.model = model;
        this.view = view;

        // Pinta el valor inicial del contador
        this.view.renderValue(this.model.getValue());

        this.view.bindIncrementClick(this.handleIncrement.bind(this));
        this.view.bindDecrementClick(this.handleDecrement.bind(this));
        this.view.bindResetClick(this.handleReset.bind(this));
    }

    handleIncrement() {
        this.view.renderValue(this.model.increment());
    }

    handleDecrement() {
        this.view.renderValue(this.model.decrement());
    }

    handleReset() {
        this.view.renderValue(this.model.reset());
    }
}
