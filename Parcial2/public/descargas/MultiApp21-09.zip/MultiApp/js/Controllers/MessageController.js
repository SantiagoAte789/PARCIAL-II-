export default class MessageController {
    constructor(model, view) {
        this.model = model;
        this.view = view;

        this.view.bindChangeClick(this.handleChange.bind(this));
    }

    handleChange() {
        const text = this.view.getMessageValue();

        if (this.model.isValidMessage(text)) {
            this.view.renderMessage(text);
        } else {
            this.view.showAlert(this.model.getEmptyMessageWarning());
        }
    }
}
