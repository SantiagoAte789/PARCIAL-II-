export default class GreetController {
    constructor(model, view) {
        this.model = model;
        this.view = view;

        this.view.bindGreetClick(this.handleGreet.bind(this));
    }

    handleGreet() {
        const name = this.view.getNameValue();

        if (this.model.isValidName(name)) {
            this.view.showAlert(this.model.buildWelcomeMessage(name));
        } else {
            this.view.showAlert(this.model.getEmptyNameMessage());
        }
    }
}
