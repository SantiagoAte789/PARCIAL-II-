export default class ToggleController {
    constructor(model, view) {
        this.model = model;
        this.view = view;

        this.view.bindShowClick(this.handleShow.bind(this));
        this.view.bindHideClick(this.handleHide.bind(this));
    }

    handleShow() {
        this.model.show();
        this.view.show();
    }

    handleHide() {
        this.model.hide();
        this.view.hide();
    }
}
