export default class MessageView {
    constructor() {
        this.input = document.getElementById("message-input");
        this.button = document.getElementById("message-btn");
        this.output = document.getElementById("message-output");
    }

    getMessageValue() {
        return this.input.value;
    }

    renderMessage(text) {
        this.output.textContent = text;
    }

    showAlert(message) {
        alert(message);
    }

    bindChangeClick(handler) {
        this.button.addEventListener("click", handler);
    }
}
