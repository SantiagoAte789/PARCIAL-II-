export default class GreetView {
    constructor() {
        this.input = document.getElementById("greet-input");
        this.button = document.getElementById("greet-btn");
    }

    getNameValue() {
        return this.input.value;
    }

    showAlert(message) {
        alert(message);
    }

    bindGreetClick(handler) {
        this.button.addEventListener("click", handler);
    }
}
