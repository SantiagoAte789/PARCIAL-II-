export default class CounterView {
    constructor() {
        this.display = document.getElementById("counter-value");
        this.incrementBtn = document.getElementById("increment-btn");
        this.decrementBtn = document.getElementById("decrement-btn");
        this.resetBtn = document.getElementById("reset-btn");
    }

    renderValue(value) {
        this.display.textContent = value;
    }

    bindIncrementClick(handler) {
        this.incrementBtn.addEventListener("click", handler);
    }

    bindDecrementClick(handler) {
        this.decrementBtn.addEventListener("click", handler);
    }

    bindResetClick(handler) {
        this.resetBtn.addEventListener("click", handler);
    }
}
