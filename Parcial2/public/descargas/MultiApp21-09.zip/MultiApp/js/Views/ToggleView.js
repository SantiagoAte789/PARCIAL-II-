export default class ToggleView {
    constructor() {
        this.section = document.getElementById("toggle-section");
        this.showBtn = document.getElementById("show-btn");
        this.hideBtn = document.getElementById("hide-btn");
    }

    show() {
        this.section.classList.remove("hidden");
    }

    hide() {
        this.section.classList.add("hidden");
    }

    bindShowClick(handler) {
        this.showBtn.addEventListener("click", handler);
    }

    bindHideClick(handler) {
        this.hideBtn.addEventListener("click", handler);
    }
}
