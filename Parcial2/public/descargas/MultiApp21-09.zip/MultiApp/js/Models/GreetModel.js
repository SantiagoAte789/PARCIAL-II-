export default class GreetModel {
    isValidName(name) {
        return typeof name === "string" && name.trim().length > 0;
    }

    buildWelcomeMessage(name) {
        return `Bienvenido: ${name.trim()}`;
    }

    getEmptyNameMessage() {
        return "Por favor, ingrese su nombre.";
    }
}
