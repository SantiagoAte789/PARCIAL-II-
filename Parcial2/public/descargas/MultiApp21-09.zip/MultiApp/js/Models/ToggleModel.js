export default class ToggleModel {
    constructor() {
        this.isVisible = true;
    }

    show() {
        this.isVisible = true;
        return this.isVisible;
    }

    hide() {
        this.isVisible = false;
        return this.isVisible;
    }
}
