export default class CounterModel {
    constructor() {
        this.value = 0;
    }

    increment() {
        this.value++;
        return this.value;
    }

    decrement() {
        this.value--;
        return this.value;
    }

    reset() {
        this.value = 0;
        return this.value;
    }

    getValue() {
        return this.value;
    }
}
