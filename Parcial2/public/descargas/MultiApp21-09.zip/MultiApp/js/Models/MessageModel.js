export default class MessageModel {
    isValidMessage(text) {
        return typeof text === "string" && text.trim().length > 0;
    }

    getEmptyMessageWarning() {
        return "Debe ingresar un mensaje.";
    }
}
